#!/system/bin/sh
#
# Copyright (C) 2024 The LineageOS Project
# SPDX-License-Identifier: Apache-2.0
#
# Set SurfaceFlinger background blur support based on available RAM
# RAM < 2GB (2097152 KB) = disable blur (0)
# RAM >= 2GB = enable blur (1)

# Get total RAM in KB
MEMTOTAL=$(grep "^MemTotal:" /proc/meminfo | awk '{print $2}')

# 2GB threshold in KB
THRESHOLD=2097152

# Log the RAM check
log -t "set_blur_support" "Checking RAM: ${MEMTOTAL} KB"

if [ "$MEMTOTAL" -lt "$THRESHOLD" ]; then
    # Low RAM device - disable blur
    setprop ro.surface_flinger.supports_background_blur 0
    log -t "set_blur_support" "RAM < 2GB detected. Disabling SurfaceFlinger blur"
else
    # High RAM device - enable blur
    setprop ro.surface_flinger.supports_background_blur 1
    log -t "set_blur_support" "RAM >= 2GB detected. Enabling SurfaceFlinger blur"
fi

# Verify the property was set
BLUR_PROP=$(getprop ro.surface_flinger.supports_background_blur)
log -t "set_blur_support" "Property set to: ${BLUR_PROP}"

exit 0
