# SurfaceFlinger Background Blur Support - Method 2 Implementation

## Overview
This implementation adds runtime RAM detection to enable/disable SurfaceFlinger background blur effect based on device RAM capacity.

**Device:** Xiaomi Blossom  
**Method:** Custom Boot Script (Method 2)  
**Threshold:** 2GB RAM

## What Was Added

### 1. New Directory Structure
```
device/xiaomi/blossom/
├── system/
│   ├── Android.bp (NEW)
│   └── etc/
│       ├── init/
│       │   └── surfaceflinger_blur.rc (NEW)
│       └── set_blur_support.sh (NEW)
```

### 2. Files Created

#### `system/etc/init/surfaceflinger_blur.rc`
- Defines a service that runs the blur configuration script
- Service runs at `late_start` class (after boot)
- One-shot execution to set the property once at startup

#### `system/etc/set_blur_support.sh`
- Shell script that checks available RAM from `/proc/meminfo`
- Compares total RAM against 2GB (2097152 KB) threshold
- Sets property based on comparison:
  - `ro.surface_flinger.supports_background_blur = 0` (RAM < 2GB)
  - `ro.surface_flinger.supports_background_blur = 1` (RAM ≥ 2GB)
- Logs all actions for debugging

#### `system/Android.bp`
- Build configuration for the new system files
- Uses `prebuilt_etc` to install scripts and configs
- Files are placed in system_ext partition

### 3. Modified Files

#### `device.mk`
**Changes:** Added new package references
```makefile
# System init files - SurfaceFlinger configuration
PRODUCT_PACKAGES += \
    surfaceflinger_blur.rc \
    set_blur_support.sh
```

## How It Works

1. **Boot Process:**
   - Device boots and init system loads all init files
   - `surfaceflinger_blur.rc` is loaded from `/system/etc/init/`

2. **Execution:**
   - On the `boot` phase, init executes: `exec_start set_blur_support`
   - This triggers the service to run the shell script

3. **RAM Check:**
   - Script reads `/proc/meminfo` to get total RAM
   - Compares value against 2GB threshold (2097152 KB)

4. **Property Setting:**
   - Script uses `setprop` to set `ro.surface_flinger.supports_background_blur`
   - Value is either 0 (disabled) or 1 (enabled)

5. **Verification:**
   - Script retrieves and logs the final property value
   - Logs appear in logcat for debugging

## Verification

Check if the property was set correctly:

```bash
adb shell getprop ro.surface_flinger.supports_background_blur
```

View RAM information:
```bash
adb shell grep MemTotal /proc/meminfo
```

Check logs:
```bash
adb logcat | grep "set_blur_support"
```

## RAM Threshold Details

- **2GB = 2097152 KB** (the threshold used in calculations)
- Devices with exactly 2GB or more → Blur enabled (value: 1)
- Devices with less than 2GB → Blur disabled (value: 0)

## Advantages of This Method

✅ Runtime detection (not build-time)  
✅ Automatically detects actual device RAM  
✅ Works with device variants that have different RAM configs  
✅ Easy to adjust threshold if needed  
✅ Includes logging for troubleshooting  
✅ Clean implementation using standard Android init system  

## Customization

### Change RAM Threshold
Edit `/system/etc/set_blur_support.sh`:
```bash
# Current (2GB)
THRESHOLD=2097152

# For 3GB threshold instead
THRESHOLD=3145728

# For 1GB threshold instead
THRESHOLD=1048576
```

### Change Which Partition
Edit `/system/Android.bp`:
```bp
// From system_ext: true
// To vendor: true
// Or product: true
```

## Testing After Build

1. Build the ROM with these changes
2. Flash to device
3. Boot and wait for system to stabilize
4. Run verification commands above
5. Check if blur effects are appropriately enabled/disabled in SystemUI

## Troubleshooting

### Property not set?
- Check if init file is in correct path: `/system/etc/init/surfaceflinger_blur.rc`
- Verify script is executable: `ls -la /system/etc/set_blur_support.sh`
- Check logcat: `adb logcat | grep "set_blur_support"`

### Wrong RAM detection?
- Verify actual RAM: `adb shell grep MemTotal /proc/meminfo`
- Check script output: `adb shell cat /proc/meminfo | grep MemTotal`

### Blur not working after property set?
- SurfaceFlinger may need restart
- Some ROM versions don't respect this property
- Device may not have blur-capable GPU

## References

- Android Init Language: https://android.googlesource.com/platform/system/core/+/master/init/README.md
- System Properties: https://developer.android.com/reference/android/os/SystemProperties
- SurfaceFlinger: https://source.android.com/devices/graphics/arch-sf

## License

Copyright (C) 2024 The LineageOS Project  
SPDX-License-Identifier: Apache-2.0
